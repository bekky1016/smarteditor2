package kh.exam.s02.notice.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;

public class Aaa {
	@RequestMapping("/abcdef")
	public String abcdef(HttpSession session) {
		String result = null;
		System.out.println("notice abcdef");

		session.setAttribute("ss1", "나의 첫 세션값");
		return result;
	}
	
	@RequestMapping("/write")
	public String abcdef2() {
		String result = null;
		System.out.println("notice write");
		
		return result;
	}
}
