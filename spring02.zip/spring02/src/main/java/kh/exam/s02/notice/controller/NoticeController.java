package kh.exam.s02.notice.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import kh.exam.s02.notice.model.service.NoticeService;
import kh.exam.s02.notice.model.vo.NoticeVo;

@RequestMapping("/notice")
@Controller
public class NoticeController {
	
	@Autowired
	private NoticeService service; // =springframework가 관리하는 객체 중에서 NoticeService인 객체를 대입시켜줌.
	
	// 이론 수업용일 뿐, 필드로 Vo를 선언하지 않음!
//	@Autowired
//	private NoticeVo nvo; //vo는 autowired 쓰면 안됨. 필요할 때마다 그때그때 만들어야..
	
	@RequestMapping("/abcdef")
	public String abcdef(HttpSession session) {
		String result = null;
		System.out.println("notice abcdef");
		session.setAttribute("ss1", "나의 첫 세션값");
		return result;
	}
	
//	@RequestMapping(value = "/write", method = RequestMethod.GET) // 이 방식도 꼭 알아두긴 해야함
	@GetMapping("/write")
	public String abcdef2(HttpServletRequest req, Model model, ModelAndView mv) {
		String result = null;
		System.out.println("notice write get");
		req.setAttribute("c2j1", "c2j1값"); //old한 방법
		model.addAttribute("c2j2", "c2j2값"); //앞으로는 이 방법 쓸것! 
		return "notice/notice_write";
	}
	
//	@RequestMapping(value = "/write", method = RequestMethod.POST) // 이 방식도 꼭 알아두긴 해야함
	@PostMapping("/write")
	public String abcdef5(NoticeVo vo
			, @RequestParam String a1
			, @RequestParam(required = false, defaultValue = "0") int a2
//			, HttpServletRequest req
			, HttpSession session) {
		String result = null;
		System.out.println("notice write post");
		
		System.out.println(a1);
		System.out.println(a2);
//		System.out.println(req.getParameter("a1"));
//		System.out.println(req.getParameter("a2"));
//		System.out.println(req.getParameter("a3"));
//		System.out.println(req.getParameter("bno"));
		
//		req.getSession();
		
		service.insert(vo);
		return "redirect:/notice/list";
	}
	
	@RequestMapping("/list")
	public void abcdef3() {
		String result = null;
		System.out.println("notice list");
//		return result;
	}
	
	@RequestMapping("/read")
	public String abcdef4() {
		String result = null;
		System.out.println("notice read");
		return result;
	}
	
}
