package kh.exam.s02.notice.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kh.exam.s02.notice.model.dao.NoticeDao;
import kh.exam.s02.notice.model.vo.NoticeVo;

@Service
public class NoticeService {
	
	@Autowired
	private NoticeDao dao;
	
	public int insert(NoticeVo vo) {
		System.out.println(">>>>NoticeService insert Param :"+ vo);
		int result = 0;
		return result;
	}
	public int updateForInsert(NoticeVo vo) {
		System.out.println(">>>>NoticeService updateForInsert Param :"+ vo);
		int result = 0;
		return result;
	}
//	update - 수정
	public int update( NoticeVo vo, int bno/*주로 PK*/) {
		int result = 0;
		return result;
	}
//	delete  - 삭제
	public int delete( int bno/*주로 PK*/) {
		int result = 0;
		return result;
	}
//	selectList  - 목록조회
	public List<NoticeVo> selectList(){
		List<NoticeVo> volist = null;
		System.out.println(volist);
		return volist;
	}

}
