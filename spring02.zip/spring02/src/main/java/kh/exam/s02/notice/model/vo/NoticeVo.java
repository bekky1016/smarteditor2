package kh.exam.s02.notice.model.vo;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

@Component("nvo")
public class NoticeVo {
	private int bno;
	private String btitle;
	private String bcontent;
	private Timestamp bdate;
	private int bcnt;
	private int bref;
	private int brelevel;
	private int brestep;
	private String bwriter;
	private String btype;
	
	
	
	public NoticeVo(int bno) {
		super();
		this.bno = bno;
	}

	public NoticeVo(int bno, String btitle) {
		super();
		this.bno = bno;
		this.btitle = btitle;
	}

	public NoticeVo() {
		super();
		setBtitle("abc");
		setBrelevel(1);
	}

	@Override
	public String toString() {
		return "NoticeVo [bno=" + bno + ", btitle=" + btitle + ", bcontent=" + bcontent + ", bdate=" + bdate + ", bcnt="
				+ bcnt + ", bref=" + bref + ", brelevel=" + brelevel + ", brestep=" + brestep + ", bwriter=" + bwriter
				+ ", btype=" + btype + "]";
	}

	public int getBno() {
		return bno;
	}

	public void setBno(int bno) {
		this.bno = bno;
	}

	public String getBtitle() {
		return btitle;
	}

	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}

	public String getBcontent() {
		return bcontent;
	}

	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}

	public Timestamp getBdate() {
		return bdate;
	}

	public void setBdate(Timestamp bdate) {
		this.bdate = bdate;
	}

	public int getBcnt() {
		return bcnt;
	}

	public void setBcnt(int bcnt) {
		this.bcnt = bcnt;
	}

	public int getBref() {
		return bref;
	}

	public void setBref(int bref) {
		this.bref = bref;
	}

	public int getBrelevel() {
		return brelevel;
	}

	public void setBrelevel(int brelevel) {
		this.brelevel = brelevel;
	}

	public int getBrestep() {
		return brestep;
	}

	public void setBrestep(int brestep) {
		this.brestep = brestep;
	}

	public String getBwriter() {
		return bwriter;
	}

	public void setBwriter(String bwriter) {
		this.bwriter = bwriter;
	}

	public String getBtype() {
		return btype;
	}

	public void setBtype(String btype) {
		this.btype = btype;
	}
	
	

}


